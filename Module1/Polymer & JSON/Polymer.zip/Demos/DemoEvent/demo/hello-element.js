import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';
import '@polymer/iron-icons/iron-icons.js';

class HelloElement extends PolymerElement{
    static get template() {
        return html`
        <h3>Welcome to polymer 3</h3>
        <div>Two Way binding</div>
        Name is <input value="{{name::input}}">
        Salary is <input value="{{salary::input}}">
        <button on-click="printDetail">Add Data</button>
        `}
        static get properties(){
            return {
                name:String,
                salary:Number
                
            };
            
        }
        
           printDetail(){
               alert("Data is "+this.name+this.salary);
           }
        
        
}
customElements.define('hello-element', HelloElement);