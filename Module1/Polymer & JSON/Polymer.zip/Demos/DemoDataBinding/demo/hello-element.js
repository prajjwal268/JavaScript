import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';
import '@polymer/iron-icons/iron-icons.js';

class HelloElement extends PolymerElement{
    static get template() {
        return html`
        <h3>Welcome to polymer 3</h3>
        <div>Two Way binding</div>
        Name is <input value="{{name::input}}">
        Salary is <input value="{{salary::input}}">
        <div>One Way binding</div>
        Name is [[name]] salary is [[salary]]
        `}
        static get properties(){
            return {
                name:String,
                salary:Number
                
            };
            
        }
        
        
}
customElements.define('hello-element', HelloElement);